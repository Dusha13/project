<?php
$host = '127.0.0.1';
$database = 'WareBase';
$user = 'adm';
$password = '1234';
?>